var structdrv__ccs811__alg__result__t =
[
    [ "ec02_ppm", "structdrv__ccs811__alg__result__t.html#ae5ee3f015ff4913757e9357e4931ff67", null ],
    [ "err_id", "structdrv__ccs811__alg__result__t.html#a46e04bca1cc93c1629541605dd85326b", null ],
    [ "raw_data", "structdrv__ccs811__alg__result__t.html#ad59757fc0efbcc998c91501915f98c22", null ],
    [ "status", "structdrv__ccs811__alg__result__t.html#aba48208a73dd4ca0e8273e01875c45bf", null ],
    [ "tvoc_ppb", "structdrv__ccs811__alg__result__t.html#a4e2800c2e0835efd55fbf2618ee66fb5", null ]
];