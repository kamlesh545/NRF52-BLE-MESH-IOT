var structdrv__ccs811__cfg__t =
[
    [ "p_twi_cfg", "structdrv__ccs811__cfg__t.html#a1f2253ccf42d0ea340e8dccfd419e829", null ],
    [ "p_twi_instance", "structdrv__ccs811__cfg__t.html#a48a051f82ed8efc7ead6dd8ba688c40e", null ],
    [ "twi_addr", "structdrv__ccs811__cfg__t.html#a3e14baa172b378a415ddee0626a62ad3", null ]
];