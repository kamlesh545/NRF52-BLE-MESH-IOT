var group__sx150x__led__drv__regs =
[
    [ "sx150x_led_drv_regs_vals_t", "structsx150x__led__drv__regs__vals__t.html", null ]
];