var structdrv__ext__light__init__t =
[
    [ "clkx_div", "structdrv__ext__light__init__t.html#a2069c7bdf6ec3f36cade163500e61b46", null ],
    [ "num_lights", "structdrv__ext__light__init__t.html#a7ad90981fe4efb810a08759bfe032dd9", null ],
    [ "p_light_conf", "structdrv__ext__light__init__t.html#a508151b70f56c4287396f61aa8f6b1fc", null ],
    [ "p_twi_conf", "structdrv__ext__light__init__t.html#a7942ffa784b49053577ed925bc0094d4", null ],
    [ "resync_pin", "structdrv__ext__light__init__t.html#af5ac896491ef67bec789e5b651ceb415", null ]
];