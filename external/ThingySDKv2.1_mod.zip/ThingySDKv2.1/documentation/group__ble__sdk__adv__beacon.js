var group__ble__sdk__adv__beacon =
[
    [ "app_beacon_init", "group__ble__sdk__adv__beacon.html#ga910fb7695461046e9960641ef24f3bd5", null ],
    [ "app_beacon_on_sys_evt", "group__ble__sdk__adv__beacon.html#ga5b124312305b07abeba16935fd12f220", null ],
    [ "app_beacon_start", "group__ble__sdk__adv__beacon.html#ga19c62b53343df829bf17cacc9a00e87f", null ],
    [ "app_beacon_stop", "group__ble__sdk__adv__beacon.html#ga750bb9f257312ff2f4187ec158178fe8", null ]
];