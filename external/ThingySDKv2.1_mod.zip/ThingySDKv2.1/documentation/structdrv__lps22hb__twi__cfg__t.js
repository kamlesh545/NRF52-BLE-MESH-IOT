var structdrv__lps22hb__twi__cfg__t =
[
    [ "p_twi_cfg", "structdrv__lps22hb__twi__cfg__t.html#a82e422f02d0201176e074be69b19bfb8", null ],
    [ "p_twi_instance", "structdrv__lps22hb__twi__cfg__t.html#aefa961e5af260e3cd327ff7c3288a5fc", null ],
    [ "pin_int", "structdrv__lps22hb__twi__cfg__t.html#abde5555a1f7b1f60d4f5eb830b30b2fc", null ],
    [ "twi_addr", "structdrv__lps22hb__twi__cfg__t.html#a2007bbc252bc4908119aa22fdd1a090e", null ]
];