var structbatt__meas__init__t =
[
    [ "batt_meas_param", "structbatt__meas__init__t.html#af63004d13b5db534cc11cbd0bb2723f7", null ],
    [ "evt_handler", "structbatt__meas__init__t.html#afbb4f0c97d0906f402bae57e4472cf4f", null ]
];