var group__ble__sdk__srv =
[
    [ "Thingy Configuration Service", "group__ble__sdk__srv__tcs.html", "group__ble__sdk__srv__tcs" ],
    [ "Thingy Environment Service", "group__ble__sdk__srv__tes.html", "group__ble__sdk__srv__tes" ],
    [ "Thingy Motion Service", "group__ble__sdk__srv__wss.html", "group__ble__sdk__srv__wss" ],
    [ "Thingy Sound Service", "group__ble__srv__tss.html", "group__ble__srv__tss" ],
    [ "Thingy User Interface Service", "group__ble__sdk__srv__uis.html", "group__ble__sdk__srv__uis" ]
];