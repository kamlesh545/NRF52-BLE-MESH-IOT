var structm__batt__meas__event__t =
[
    [ "level_percent", "structm__batt__meas__event__t.html#ab5428192b1c275fe39849bd5296bcf38", null ],
    [ "type", "structm__batt__meas__event__t.html#a535ad3ffcec3974575eb7e08fcc8ebc2", null ],
    [ "valid_voltage", "structm__batt__meas__event__t.html#af3bba3b6ab6d11e014929bd6726e21ad", null ],
    [ "voltage_mv", "structm__batt__meas__event__t.html#a68a8c5c913af88ed9100abd8e391ae25", null ]
];