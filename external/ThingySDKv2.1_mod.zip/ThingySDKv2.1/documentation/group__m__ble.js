var group__m__ble =
[
    [ "BLE flash configuration", "group__m__ble__flash.html", "group__m__ble__flash" ],
    [ "m_ble_evt_t", "structm__ble__evt__t.html", null ],
    [ "m_ble_init_t", "structm__ble__init__t.html", null ],
    [ "m_ble_service_handle_t", "structm__ble__service__handle__t.html", null ],
    [ "m_ble_service_evt_cb_t", "group__m__ble.html#gaacee7761d073396b213e95753cf08bd2", null ],
    [ "m_ble_evt_type_t", "group__m__ble.html#ga38cef9bcea26e35beb37bc791bc53955", null ],
    [ "m_ble_init", "group__m__ble.html#ga0f4cc6ddb2afa86f25cbce12a7b6a0cf", null ],
    [ "m_ble_start", "group__m__ble.html#ga6a970aea3fdc66ccc6aee5d58973304f", null ],
    [ "m_ble_stop", "group__m__ble.html#ga6b0abe41ff9c1eafe92b268b2ce66043", null ]
];