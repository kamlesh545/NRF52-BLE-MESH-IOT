var group__modules =
[
    [ "BLE", "group__m__ble.html", "group__m__ble" ],
    [ "Battery measurement", "group__m__batt__meas.html", "group__m__batt__meas" ],
    [ "Environment", "group__m__environment.html", "group__m__environment" ],
    [ "Motion", "group__m__motion.html", "group__m__motion" ],
    [ "Sound", "group__m__sound.html", "group__m__sound" ],
    [ "User interface", "group__m__ui.html", "group__m__ui" ]
];