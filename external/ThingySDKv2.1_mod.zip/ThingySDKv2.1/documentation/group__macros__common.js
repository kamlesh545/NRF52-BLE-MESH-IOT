var group__macros__common =
[
    [ "NULL_PARAM_CHECK", "group__macros__common.html#gab5a9c73cfbaa45227d8a46c0172b5062", null ],
    [ "RETURN_IF_ERROR", "group__macros__common.html#ga9569c9f687ab7b38b551ba2ff803f096", null ]
];