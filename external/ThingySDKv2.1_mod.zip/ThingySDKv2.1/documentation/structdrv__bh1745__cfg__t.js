var structdrv__bh1745__cfg__t =
[
    [ "p_twi_cfg", "structdrv__bh1745__cfg__t.html#ad10575e87f9533f2b962fd63fb6741cf", null ],
    [ "p_twi_instance", "structdrv__bh1745__cfg__t.html#a76dc6693e0620bd19de24dbc919f2d46", null ],
    [ "twi_addr", "structdrv__bh1745__cfg__t.html#a88416289c804022281aeefb1d0c665a8", null ]
];