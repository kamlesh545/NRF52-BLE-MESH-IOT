var modules =
[
    [ "BLE services", "group__ble__sdk__srv.html", "group__ble__sdk__srv" ],
    [ "Drivers", "group__drivers.html", "group__drivers" ],
    [ "Thingy modules", "group__modules.html", "group__modules" ],
    [ "Utilities", "group__util.html", "group__util" ]
];