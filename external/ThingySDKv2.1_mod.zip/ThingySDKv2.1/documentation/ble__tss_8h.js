var ble__tss_8h =
[
    [ "BLE_TSS_MAX_DATA_LEN", "group__ble__srv__tss.html#ga01ccdfec98d9345ac7ec9d35fd186a74", null ],
    [ "BLE_UUID_TSS_SERVICE", "group__ble__srv__tss.html#ga97ea4228f5ce9f33036b451a21dd7d4e", null ],
    [ "ble_tss_evt_handler_t", "group__ble__srv__tss.html#gac063250d7d8dd0c55073c747306eb452", null ],
    [ "ble_tss_init", "group__ble__srv__tss.html#ga3cad4a25955b00dc99b931dd37f91d77", null ],
    [ "ble_tss_mic_set", "group__ble__srv__tss.html#ga01ca54da607d250e6f113c35f3c66614", null ],
    [ "ble_tss_on_ble_evt", "group__ble__srv__tss.html#gaeab153e0eed3564e841c3bd9fda47962", null ],
    [ "ble_tss_spkr_stat_set", "group__ble__srv__tss.html#gafcc18b076ebbd36ae893ae8291e9ca8f", null ]
];