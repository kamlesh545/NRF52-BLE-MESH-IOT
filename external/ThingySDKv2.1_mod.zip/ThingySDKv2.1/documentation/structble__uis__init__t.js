var structble__uis__init__t =
[
    [ "led_write_handler", "structble__uis__init__t.html#af080cc44ee6ce05b2e005426109817e4", null ],
    [ "pin_write_handler", "structble__uis__init__t.html#ab979eb4ac33410f2a745b8e91102152f", null ]
];