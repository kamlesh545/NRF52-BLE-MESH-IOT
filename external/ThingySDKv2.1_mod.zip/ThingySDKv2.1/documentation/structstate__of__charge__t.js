var structstate__of__charge__t =
[
    [ "delta_mv", "structstate__of__charge__t.html#a3c599a3aa0d44107e3ca04d19773d32c", null ],
    [ "first_element_mv", "structstate__of__charge__t.html#aea6f5da870665e5460e72ba375fe1fd1", null ],
    [ "num_elements", "structstate__of__charge__t.html#a77cfde237d402d3004891f26e7023cea", null ],
    [ "voltage_to_soc", "structstate__of__charge__t.html#abfc39dcdd555c9753128ba539437797c", null ]
];