var structdrv__pressure__init__t =
[
    [ "evt_handler", "structdrv__pressure__init__t.html#a6924cf662c137957694235b6efe10f6d", null ],
    [ "mode", "structdrv__pressure__init__t.html#a00a79d19adaa7ced5fa348a3721cf927", null ],
    [ "p_twi_cfg", "structdrv__pressure__init__t.html#ac3c98cde1c88197893b63939ab3c52bb", null ],
    [ "p_twi_instance", "structdrv__pressure__init__t.html#ae6919e1fa40ec06f070c7272720ed5f1", null ],
    [ "pin_int", "structdrv__pressure__init__t.html#a2dc057303d939b535cadbcdb6f6826d4", null ],
    [ "twi_addr", "structdrv__pressure__init__t.html#a24077526a99aacf024a0cc2d2d55e45c", null ]
];