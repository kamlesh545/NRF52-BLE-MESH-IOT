var structble__tss__s =
[
    [ "config_handles", "structble__tss__s.html#a481ec3f7ee18ecd6d14a9c2a70134517", null ],
    [ "conn_handle", "structble__tss__s.html#a48993b1d6ff8521f49780e456b3dc267", null ],
    [ "evt_handler", "structble__tss__s.html#aeb752d469c07a6dd6eea79dd210bf131", null ],
    [ "is_mic_notif_enabled", "structble__tss__s.html#a5ab547d3482e36f31cf9541ce7369142", null ],
    [ "is_spkr_stat_notif_enabled", "structble__tss__s.html#ac3edb2d5de334cc97356beb9e3a451d9", null ],
    [ "mic_handles", "structble__tss__s.html#a5bd4e62bb92301c89bad2b3ab259d396", null ],
    [ "service_handle", "structble__tss__s.html#a90070ca22864840c3030dc2320a87bf6", null ],
    [ "spkr_handles", "structble__tss__s.html#ad9f8508241e4c33f825e086f23eea208", null ],
    [ "spkr_stat_handles", "structble__tss__s.html#af93f2d8a136fd443abb6aae36ea8b89e", null ],
    [ "uuid_type", "structble__tss__s.html#aa95b6acb8a85b14ea5e350ccbe5b56cd", null ]
];