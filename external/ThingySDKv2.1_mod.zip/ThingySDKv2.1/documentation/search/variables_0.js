var searchData=
[
  ['active_5ftime_5fms',['active_time_ms',['../structdrv__ext__light__status__t.html#a9cc5cb3a61f1ed082266362135887d07',1,'drv_ext_light_status_t']]],
  ['adc_5fpin_5fno',['adc_pin_no',['../structbatt__meas__param__t.html#a0fa6444796cc22152ae2357a9de7ae63',1,'batt_meas_param_t']]],
  ['adc_5fpin_5fno_5fain',['adc_pin_no_ain',['../structbatt__meas__param__t.html#a235e3292de0a02e964849b06b8a7d704',1,'batt_meas_param_t']]],
  ['adv_5fparam_5fhandles',['adv_param_handles',['../structble__tcs__s.html#a3bc36c7a22700bb4e64b5ab49bea4a5c',1,'ble_tcs_s']]],
  ['app_5ftimer_5fprescaler',['app_timer_prescaler',['../structbatt__meas__param__t.html#a9ca8fd3a0a0041f1d51e0824463f6c43',1,'batt_meas_param_t']]]
];
