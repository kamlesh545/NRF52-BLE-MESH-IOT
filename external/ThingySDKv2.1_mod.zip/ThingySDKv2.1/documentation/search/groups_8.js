var searchData=
[
  ['motion',['Motion',['../group__m__motion.html',1,'']]],
  ['motion_20flash_20configuration',['Motion flash configuration',['../group__m__motion__flash__config.html',1,'']]],
  ['microphone_20driver',['Microphone driver',['../group__mic__driver.html',1,'']]],
  ['motion_20sensor',['Motion sensor',['../group__motion__driver.html',1,'']]],
  ['mpu_2d9250_20motion_20sensor',['MPU-9250 motion sensor',['../group__mpu9250__motion__sensor.html',1,'']]]
];
