var searchData=
[
  ['sequence_5fvals',['sequence_vals',['../structdrv__ext__light__rgb__sequence__t.html#a1ff89d7d160e9019b4cf4f442f402d5d',1,'drv_ext_light_rgb_sequence_t']]],
  ['service_5fhandle',['service_handle',['../structble__tcs__s.html#a7cdf0bc64e301eb2cbc8cd23f9239d54',1,'ble_tcs_s::service_handle()'],['../structble__tes__s.html#a2b97b4bd65a3db36f639185cad6b1689',1,'ble_tes_s::service_handle()'],['../structble__tms__s.html#a22d06c50c636cb24111299d5dd4d5364',1,'ble_tms_s::service_handle()'],['../structble__tss__s.html#a90070ca22864840c3030dc2320a87bf6',1,'ble_tss_s::service_handle()'],['../structble__uis__s.html#a1f24b6cf8a54494dce4a0bbaa219902e',1,'ble_uis_s::service_handle()']]],
  ['spkr_5fhandles',['spkr_handles',['../structble__tss__s.html#ad9f8508241e4c33f825e086f23eea208',1,'ble_tss_s']]],
  ['spkr_5fstat_5fhandles',['spkr_stat_handles',['../structble__tss__s.html#af93f2d8a136fd443abb6aae36ea8b89e',1,'ble_tss_s']]],
  ['state_5fof_5fcharge',['state_of_charge',['../structbatt__meas__param__t.html#a14f6f056ef9542eb14fe43800f0cd78a',1,'batt_meas_param_t']]],
  ['status',['status',['../structdrv__ccs811__alg__result__t.html#aba48208a73dd4ca0e8273e01875c45bf',1,'drv_ccs811_alg_result_t']]]
];
