var searchData=
[
  ['num_5felements',['num_elements',['../structstate__of__charge__t.html#a77cfde237d402d3004891f26e7023cea',1,'state_of_charge_t']]],
  ['num_5flights',['num_lights',['../structdrv__ext__light__init__t.html#a7ad90981fe4efb810a08759bfe032dd9',1,'drv_ext_light_init_t']]]
];
