var searchData=
[
  ['data_5fhandler',['data_handler',['../structdrv__gas__init__t.html#a99009da1f54e5be7ed4f1854876e8f12',1,'drv_gas_init_t']]],
  ['delta_5fmv',['delta_mv',['../structstate__of__charge__t.html#a3c599a3aa0d44107e3ca04d19773d32c',1,'state_of_charge_t']]],
  ['dev_5fname_5fhandles',['dev_name_handles',['../structble__tcs__s.html#a3a063a210dd344b831584717989c8549',1,'ble_tcs_s']]]
];
