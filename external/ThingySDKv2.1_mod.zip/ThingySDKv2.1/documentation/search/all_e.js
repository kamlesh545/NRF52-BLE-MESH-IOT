var searchData=
[
  ['quat_5fhandles',['quat_handles',['../structble__tms__s.html#a17b793065cf8fcd9d24f4a3efb3a84bd',1,'ble_tms_s']]]
];
