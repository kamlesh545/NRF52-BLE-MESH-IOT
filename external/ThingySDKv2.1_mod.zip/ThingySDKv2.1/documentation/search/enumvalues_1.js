var searchData=
[
  ['clickdouble',['ClickDouble',['../group__lis3dh__acc.html#ggaab84012c26574a34c9334e573449a939a7a664a848258eae3246bab07acb9d945',1,'drv_acc_lis3dh_types.h']]],
  ['clicksingle',['ClickSingle',['../group__lis3dh__acc.html#ggaab84012c26574a34c9334e573449a939a2388ba9f829a37d6a38577dbd72465d0',1,'drv_acc_lis3dh_types.h']]]
];
