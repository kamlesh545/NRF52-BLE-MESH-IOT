var searchData=
[
  ['extender_5fosc_5funused',['EXTENDER_OSC_UNUSED',['../group__gpio__ext__driver__led.html#ggad263d177e76a81d90bd0db8e5fe9385cae99661732c937559d4ca54e9918c6c2a',1,'drv_ext_light.h']]],
  ['extender_5fosc_5fused_5fpaused',['EXTENDER_OSC_USED_PAUSED',['../group__gpio__ext__driver__led.html#ggad263d177e76a81d90bd0db8e5fe9385ca5f082501e46d840360ef0675fb274b63',1,'drv_ext_light.h']]],
  ['extender_5fosc_5fused_5fperm',['EXTENDER_OSC_USED_PERM',['../group__gpio__ext__driver__led.html#ggad263d177e76a81d90bd0db8e5fe9385caa56831e76c12a706a67a03916e25482a',1,'drv_ext_light.h']]],
  ['extender_5fosc_5fused_5frunning',['EXTENDER_OSC_USED_RUNNING',['../group__gpio__ext__driver__led.html#ggad263d177e76a81d90bd0db8e5fe9385ca103a89f09b1e03b2d0014bf6d5d93803',1,'drv_ext_light.h']]]
];
