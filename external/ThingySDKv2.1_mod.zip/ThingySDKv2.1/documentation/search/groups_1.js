var searchData=
[
  ['bh1745_20color_20sensor',['BH1745 color sensor',['../group__bh1745__color.html',1,'']]],
  ['ble_20services',['BLE services',['../group__ble__sdk__srv.html',1,'']]],
  ['battery_20measurement',['Battery measurement',['../group__m__batt__meas.html',1,'']]],
  ['ble',['BLE',['../group__m__ble.html',1,'']]],
  ['ble_20flash_20configuration',['BLE flash configuration',['../group__m__ble__flash.html',1,'']]]
];
