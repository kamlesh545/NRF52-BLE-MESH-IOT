var searchData=
[
  ['firmware_20upgrade_20using_20nrfgo_20studio_20_28cable_20connection_29',['Firmware upgrade using nRFgo Studio (cable connection)',['../dfu_cable.html',1,'dfu']]],
  ['firmware_20architecture',['Firmware architecture',['../firmware_architecture.html',1,'']]]
];
