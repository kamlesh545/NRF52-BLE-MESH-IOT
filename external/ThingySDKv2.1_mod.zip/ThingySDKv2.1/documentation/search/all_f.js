var searchData=
[
  ['r',['r',['../structdrv__ext__light__conf__t.html#a428eead9f2186ce211fd2c70a4aab011',1,'drv_ext_light_conf_t::r()'],['../structdrv__ext__light__rgb__intensity__t.html#a67ae5f19c0f521ace6d9afac0ff590f4',1,'drv_ext_light_rgb_intensity_t::r()']]],
  ['raw_5fdata',['raw_data',['../structdrv__ccs811__alg__result__t.html#ad59757fc0efbcc998c91501915f98c22',1,'drv_ccs811_alg_result_t']]],
  ['raw_5fhandles',['raw_handles',['../structble__tms__s.html#a6760a4b9d47b9ab53d0e0ad045baffd3',1,'ble_tms_s']]],
  ['ref_5fp_5fh_5freg',['REF_P_H_REG',['../group__lps22hb__press__driver.html#ga9d2231a3ff2a1b5604a44ceedcede20c',1,'drv_lps22hb.h']]],
  ['ref_5fp_5fl_5freg',['REF_P_L_REG',['../group__lps22hb__press__driver.html#gaac660a7f3084def447bbb00c58ff75e9',1,'drv_lps22hb.h']]],
  ['ref_5fp_5fxl_5freg',['REF_P_XL_REG',['../group__lps22hb__press__driver.html#ga48d69d5a9167fe631f205aa2968d01d6',1,'drv_lps22hb.h']]],
  ['release_20notes',['Release Notes',['../release_notes.html',1,'']]],
  ['res_5fconf_5freg',['RES_CONF_REG',['../group__lps22hb__press__driver.html#gabccd4c753c04c375e57ba2ec4b5a5437',1,'drv_lps22hb.h']]],
  ['res_5fconf_5freg_5flc_5fen_5fpos',['RES_CONF_REG_LC_EN_Pos',['../group__lps22hb__press__driver.html#ga74225339c4fd0afa1dae3bbcbb2ef16b',1,'drv_lps22hb.h']]],
  ['resync_5fpin',['resync_pin',['../structdrv__ext__light__init__t.html#af5ac896491ef67bec789e5b651ceb415',1,'drv_ext_light_init_t']]],
  ['return_5fif_5ferror',['RETURN_IF_ERROR',['../group__macros__common.html#ga9569c9f687ab7b38b551ba2ff803f096',1,'macros_common.h']]],
  ['rot_5fmat_5fhandles',['rot_mat_handles',['../structble__tms__s.html#a37b905ebebc898d0fe57df56b7cb1ca7',1,'ble_tms_s']]],
  ['rpds_5fh_5freg',['RPDS_H_REG',['../group__lps22hb__press__driver.html#ga10c14786c00197b9eecee85a79188351',1,'drv_lps22hb.h']]],
  ['rpds_5fl_5freg',['RPDS_L_REG',['../group__lps22hb__press__driver.html#ga42bd994fb8ddc1354c573efc927ef26a',1,'drv_lps22hb.h']]]
];
