var searchData=
[
  ['nfc_20support',['NFC support',['../nfc.html',1,'']]]
];
