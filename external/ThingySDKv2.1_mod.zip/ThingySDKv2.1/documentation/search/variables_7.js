var searchData=
[
  ['heading_5fhandles',['heading_handles',['../structble__tms__s.html#a2ef7257cb735ba8f5f517de174af6a91',1,'ble_tms_s']]],
  ['humidity_5fhandles',['humidity_handles',['../structble__tes__s.html#a5a7e4a70376b43537355d5074f616426',1,'ble_tes_s']]]
];
