var searchData=
[
  ['r',['r',['../structdrv__ext__light__conf__t.html#a428eead9f2186ce211fd2c70a4aab011',1,'drv_ext_light_conf_t::r()'],['../structdrv__ext__light__rgb__intensity__t.html#a67ae5f19c0f521ace6d9afac0ff590f4',1,'drv_ext_light_rgb_intensity_t::r()']]],
  ['raw_5fdata',['raw_data',['../structdrv__ccs811__alg__result__t.html#ad59757fc0efbcc998c91501915f98c22',1,'drv_ccs811_alg_result_t']]],
  ['raw_5fhandles',['raw_handles',['../structble__tms__s.html#a6760a4b9d47b9ab53d0e0ad045baffd3',1,'ble_tms_s']]],
  ['resync_5fpin',['resync_pin',['../structdrv__ext__light__init__t.html#af5ac896491ef67bec789e5b651ceb415',1,'drv_ext_light_init_t']]],
  ['rot_5fmat_5fhandles',['rot_mat_handles',['../structble__tms__s.html#a37b905ebebc898d0fe57df56b7cb1ca7',1,'ble_tms_s']]]
];
