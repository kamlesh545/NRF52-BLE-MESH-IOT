var searchData=
[
  ['m_5fbatt_5fmeas_5fevent_5fhandler_5ft',['m_batt_meas_event_handler_t',['../group__m__batt__meas.html#ga3a8f1eaf8376db27cdc7a87946c84c37',1,'m_batt_meas.h']]],
  ['m_5fble_5fservice_5fevt_5fcb_5ft',['m_ble_service_evt_cb_t',['../group__m__ble.html#gaacee7761d073396b213e95753cf08bd2',1,'m_ble.h']]]
];
