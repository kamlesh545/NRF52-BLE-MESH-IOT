var searchData=
[
  ['led_5fchar_5fhandles',['led_char_handles',['../structble__uis__s.html#ac1b173438ef00fb8687d979309d917d4',1,'ble_uis_s']]],
  ['led_5fwrite_5fhandler',['led_write_handler',['../structble__uis__init__t.html#af080cc44ee6ce05b2e005426109817e4',1,'ble_uis_init_t::led_write_handler()'],['../structble__uis__s.html#a2198cbc105e8c8f6b4ebb4cfc285b0b5',1,'ble_uis_s::led_write_handler()']]],
  ['level_5fpercent',['level_percent',['../structm__batt__meas__event__t.html#ab5428192b1c275fe39849bd5296bcf38',1,'m_batt_meas_event_t']]]
];
