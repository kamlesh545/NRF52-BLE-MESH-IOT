var searchData=
[
  ['usb_5fdetect_5fpin_5fno',['usb_detect_pin_no',['../structbatt__meas__param__t.html#af749236629b2501099b6261ebe398583',1,'batt_meas_param_t']]],
  ['uuid_5ftype',['uuid_type',['../structble__tcs__s.html#a16efefe964dc754bb9aba36bb3656580',1,'ble_tcs_s::uuid_type()'],['../structble__tes__s.html#ae26fbda6885f907faff6a45b58649017',1,'ble_tes_s::uuid_type()'],['../structble__tms__s.html#adf610dcfe680194d9f5a5184fd8befbd',1,'ble_tms_s::uuid_type()'],['../structble__tss__s.html#aa95b6acb8a85b14ea5e350ccbe5b56cd',1,'ble_tss_s::uuid_type()'],['../structble__uis__s.html#a75316520f8803e9a2c7cc2d70c5d6a7a',1,'ble_uis_s::uuid_type()']]]
];
