var searchData=
[
  ['clickmode_5ft',['ClickMode_t',['../group__lis3dh__acc.html#gaab84012c26574a34c9334e573449a939',1,'drv_acc_lis3dh_types.h']]]
];
