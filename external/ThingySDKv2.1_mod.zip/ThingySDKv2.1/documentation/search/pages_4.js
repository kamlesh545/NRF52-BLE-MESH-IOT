var searchData=
[
  ['over_2dthe_2dair_20device_20firmware_20update_20_28ota_2ddfu_29',['Over-the-air device firmware update (OTA-DFU)',['../dfu.html',1,'']]],
  ['ota_2ddfu_20with_20nrf_20connect',['OTA-DFU with nRF Connect',['../dfu_connect.html',1,'dfu']]],
  ['ota_2ddfu_20_2d_20generating_20your_20own_20packages',['OTA-DFU - Generating your own packages',['../dfu_generating.html',1,'dfu']]]
];
