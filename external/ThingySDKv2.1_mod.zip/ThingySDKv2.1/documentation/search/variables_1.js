var searchData=
[
  ['b',['b',['../structdrv__ext__light__conf__t.html#ab4318f02bebda5f69666bed4273cd57e',1,'drv_ext_light_conf_t::b()'],['../structdrv__ext__light__rgb__intensity__t.html#a5f137d6708765a5bb84273e06645a992',1,'drv_ext_light_rgb_intensity_t::b()']]],
  ['batt_5fchg_5fstat_5fpin_5fno',['batt_chg_stat_pin_no',['../structbatt__meas__param__t.html#aeb8fcc57a40fd7458aa6d31549577d82',1,'batt_meas_param_t']]],
  ['batt_5fmeas_5fparam',['batt_meas_param',['../structbatt__meas__init__t.html#af63004d13b5db534cc11cbd0bb2723f7',1,'batt_meas_init_t']]],
  ['batt_5fmon_5fen_5fpin_5fno',['batt_mon_en_pin_no',['../structbatt__meas__param__t.html#a310d12d80f4448fca30df7e26e1224a5',1,'batt_meas_param_t']]],
  ['batt_5fmon_5fen_5fpin_5fused',['batt_mon_en_pin_used',['../structbatt__meas__param__t.html#a8fd3192d7233181b20d89f9e277a7967',1,'batt_meas_param_t']]],
  ['batt_5fvoltage_5flimit_5ffull',['batt_voltage_limit_full',['../structbatt__meas__param__t.html#a87835cef0315ba5c39c0e63ad552c5f7',1,'batt_meas_param_t']]],
  ['batt_5fvoltage_5flimit_5flow',['batt_voltage_limit_low',['../structbatt__meas__param__t.html#af15ce3f05c8b27c32ac601445a33e110',1,'batt_meas_param_t']]],
  ['button_5fchar_5fhandles',['button_char_handles',['../structble__uis__s.html#a9186f55308e5026990f0189db5d0999a',1,'ble_uis_s']]]
];
