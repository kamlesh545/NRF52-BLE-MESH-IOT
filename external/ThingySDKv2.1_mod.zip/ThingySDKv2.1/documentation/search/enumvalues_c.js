var searchData=
[
  ['sx150x_5fled_5fdrc_5fcalc_5fstatus_5fcode_5fsuccess',['SX150x_LED_DRC_CALC_STATUS_CODE_SUCCESS',['../group__sx150x__led__drv__calc.html#ggab04a0655cd1e3bcac5e8f48c18df1a57a0aa0d95c9054e90eef9fbb3722abff6a',1,'sx150x_led_drv_calc.h']]],
  ['sx150x_5fled_5fdrv_5fcalc_5fstatus_5fcode_5finaccurate',['SX150x_LED_DRV_CALC_STATUS_CODE_INACCURATE',['../group__sx150x__led__drv__calc.html#ggab04a0655cd1e3bcac5e8f48c18df1a57acb840217932f263328ae89456652958e',1,'sx150x_led_drv_calc.h']]],
  ['sx150x_5fled_5fdrv_5fcalc_5fstatus_5fcode_5finvalid_5fparam',['SX150x_LED_DRV_CALC_STATUS_CODE_INVALID_PARAM',['../group__sx150x__led__drv__calc.html#ggab04a0655cd1e3bcac5e8f48c18df1a57a1b97777ad94b5f9a437763a3b311aa7b',1,'sx150x_led_drv_calc.h']]],
  ['sx150x_5fled_5fdrv_5fcalc_5fstatus_5fcode_5fnot_5finit',['SX150x_LED_DRV_CALC_STATUS_CODE_NOT_INIT',['../group__sx150x__led__drv__calc.html#ggab04a0655cd1e3bcac5e8f48c18df1a57ad6c5773978cfc8497a7123d516774d25',1,'sx150x_led_drv_calc.h']]],
  ['sx150x_5fled_5fdrv_5fcalc_5fstatus_5fcode_5fnull',['SX150x_LED_DRV_CALC_STATUS_CODE_NULL',['../group__sx150x__led__drv__calc.html#ggab04a0655cd1e3bcac5e8f48c18df1a57a5f78b0f4b03236abab2f9e4123785c3c',1,'sx150x_led_drv_calc.h']]]
];
