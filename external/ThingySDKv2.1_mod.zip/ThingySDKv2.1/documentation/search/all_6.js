var searchData=
[
  ['g',['g',['../structdrv__ext__light__conf__t.html#a2b68ad38e7f8e78b5d1928e1b5ec8400',1,'drv_ext_light_conf_t::g()'],['../structdrv__ext__light__rgb__intensity__t.html#a5ba9b8a1724cc721f0a6fc851b7ef05e',1,'drv_ext_light_rgb_intensity_t::g()']]],
  ['gas_5fhandles',['gas_handles',['../structble__tes__s.html#ab797036eca6455634b591a13b7236671',1,'ble_tes_s']]],
  ['gas_20sensor',['Gas sensor',['../group__gas__sensor.html',1,'']]],
  ['gpio_20extender',['GPIO extender',['../group__gpio__ext__driver.html',1,'']]],
  ['gpio_20extender_20led_20driver',['GPIO extender LED driver',['../group__gpio__ext__driver__led.html',1,'']]],
  ['gravity_5fhandles',['gravity_handles',['../structble__tms__s.html#a3cda72a29dcfbf62db7caa3a0ff8bd71',1,'ble_tms_s']]]
];
