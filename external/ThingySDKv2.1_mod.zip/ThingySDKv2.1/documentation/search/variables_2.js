var searchData=
[
  ['clkx_5fdiv',['clkx_div',['../structdrv__ext__light__init__t.html#a2069c7bdf6ec3f36cade163500e61b46',1,'drv_ext_light_init_t']]],
  ['color',['color',['../structdrv__ext__light__rgb__sequence__t.html#a2da4bc8b6b4448f3e2608be112a51495',1,'drv_ext_light_rgb_sequence_t']]],
  ['color_5fhandles',['color_handles',['../structble__tes__s.html#ae8da8a9b395e3cbb704886374426f1b0',1,'ble_tes_s']]],
  ['colors',['colors',['../structdrv__ext__light__status__t.html#a88722f81f025fd8ce2c083ac51c53478',1,'drv_ext_light_status_t']]],
  ['config_5fhandles',['config_handles',['../structble__tes__s.html#aefdcf700902a328508a74c7ca1b68ced',1,'ble_tes_s::config_handles()'],['../structble__tms__s.html#a11a2e2d06c8e71048abad3d974f201cf',1,'ble_tms_s::config_handles()'],['../structble__tss__s.html#a481ec3f7ee18ecd6d14a9c2a70134517',1,'ble_tss_s::config_handles()']]],
  ['conn_5fhandle',['conn_handle',['../structble__tcs__s.html#aa0614613b1c7bc22a4e8c8f2eb92f9fa',1,'ble_tcs_s::conn_handle()'],['../structble__tes__s.html#a6d8b5027bf012e19727f81a97566452d',1,'ble_tes_s::conn_handle()'],['../structble__tms__s.html#a291e1cb1a00e5d2eab1d808719931dcb',1,'ble_tms_s::conn_handle()'],['../structble__tss__s.html#a48993b1d6ff8521f49780e456b3dc267',1,'ble_tss_s::conn_handle()'],['../structble__uis__s.html#adbd2ed630faadf6a10cc402f6438d6ce',1,'ble_uis_s::conn_handle()']]],
  ['conn_5fparam_5fhandles',['conn_param_handles',['../structble__tcs__s.html#a4ef5b98d85969326176dbe37ac1f5536',1,'ble_tcs_s']]],
  ['cpu_5fwake_5fpin',['cpu_wake_pin',['../structdrv__acc__cfg__t.html#a2c1936d9a000add1c5d56b45e30f3a7b',1,'drv_acc_cfg_t']]]
];
