var searchData=
[
  ['thingy_20configuration_20service',['Thingy Configuration Service',['../group__ble__sdk__srv__tcs.html',1,'']]],
  ['thingy_20environment_20service',['Thingy Environment Service',['../group__ble__sdk__srv__tes.html',1,'']]],
  ['thingy_20user_20interface_20service',['Thingy User Interface Service',['../group__ble__sdk__srv__uis.html',1,'']]],
  ['thingy_20motion_20service',['Thingy Motion Service',['../group__ble__sdk__srv__wss.html',1,'']]],
  ['thingy_20sound_20service',['Thingy Sound Service',['../group__ble__srv__tss.html',1,'']]],
  ['thingy_20modules',['Thingy modules',['../group__modules.html',1,'']]]
];
