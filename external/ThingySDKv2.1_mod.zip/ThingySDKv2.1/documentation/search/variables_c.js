var searchData=
[
  ['orientation_5fhandles',['orientation_handles',['../structble__tms__s.html#a8247e36053b95838ec8a84d641254fea',1,'ble_tms_s']]]
];
