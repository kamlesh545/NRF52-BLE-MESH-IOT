var structble__uis__s =
[
    [ "button_char_handles", "structble__uis__s.html#a9186f55308e5026990f0189db5d0999a", null ],
    [ "conn_handle", "structble__uis__s.html#adbd2ed630faadf6a10cc402f6438d6ce", null ],
    [ "led_char_handles", "structble__uis__s.html#ac1b173438ef00fb8687d979309d917d4", null ],
    [ "led_write_handler", "structble__uis__s.html#a2198cbc105e8c8f6b4ebb4cfc285b0b5", null ],
    [ "pin_char_handles", "structble__uis__s.html#aa25e0f1f49116b30904615041478e770", null ],
    [ "pin_write_handler", "structble__uis__s.html#a97a7f969603f47ac5d1ae11eac65c4f3", null ],
    [ "service_handle", "structble__uis__s.html#a1f24b6cf8a54494dce4a0bbaa219902e", null ],
    [ "uuid_type", "structble__uis__s.html#a75316520f8803e9a2c7cc2d70c5d6a7a", null ]
];