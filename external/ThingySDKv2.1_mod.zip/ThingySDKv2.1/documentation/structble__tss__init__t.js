var structble__tss__init__t =
[
    [ "evt_handler", "structble__tss__init__t.html#a5866fa76b71a7ec8a02f1c110e27b84f", null ]
];