var group__bh1745__color =
[
    [ "drv_bh1745_cfg_t", "structdrv__bh1745__cfg__t.html", [
      [ "p_twi_cfg", "structdrv__bh1745__cfg__t.html#ad10575e87f9533f2b962fd63fb6741cf", null ],
      [ "p_twi_instance", "structdrv__bh1745__cfg__t.html#a76dc6693e0620bd19de24dbc919f2d46", null ],
      [ "twi_addr", "structdrv__bh1745__cfg__t.html#a88416289c804022281aeefb1d0c665a8", null ]
    ] ],
    [ "drv_bh1745_data_t", "structdrv__bh1745__data__t.html", null ],
    [ "drv_bh1745_threshold_t", "structdrv__bh1745__threshold__t.html", null ],
    [ "drv_bh1745_gain_t", "group__bh1745__color.html#gabfd0fbafeb40237bdc3653bdb4db70cf", null ],
    [ "drv_bh1745_meas_time_t", "group__bh1745__color.html#gabe36d490de5a064dba654d29a80c7b3a", null ],
    [ "drv_bh1745_close", "group__bh1745__color.html#ga036cd2e4adc00f85f4cdb97ed9ecff1e", null ],
    [ "drv_bh1745_data_get", "group__bh1745__color.html#ga6795dc64922cabf0feafc78a4e168dbb", null ],
    [ "drv_bh1745_gain_set", "group__bh1745__color.html#ga43659c0bf27ebf16ccd9dde8300acc04", null ],
    [ "drv_bh1745_init", "group__bh1745__color.html#ga76d28dd092160421654e38ac87ebb4b3", null ],
    [ "drv_bh1745_int_get", "group__bh1745__color.html#ga1e4f0cf16a33478f6a46560b2e4b159d", null ],
    [ "drv_bh1745_int_reset", "group__bh1745__color.html#ga61527a1ca099183973142ff928b3412e", null ],
    [ "drv_bh1745_int_set", "group__bh1745__color.html#gae392774121ee932b5d3acda0de142657", null ],
    [ "drv_bh1745_manu_id_get", "group__bh1745__color.html#gafda2b23732c3bd1e661d2f0e01598a43", null ],
    [ "drv_bh1745_meas_enable", "group__bh1745__color.html#ga09607c3012886317a9827e0442fe438e", null ],
    [ "drv_bh1745_meas_time_set", "group__bh1745__color.html#ga6513b8f116fe394b20a01aee50cbc99a", null ],
    [ "drv_bh1745_open", "group__bh1745__color.html#gaeb0b73a73825ac06e45236517bd54532", null ],
    [ "drv_bh1745_part_id_get", "group__bh1745__color.html#gae40c33fdb63209e8ac4a0ff9fa8e163d", null ],
    [ "drv_bh1745_persistance_get", "group__bh1745__color.html#ga23a22ad13c11a51284c0a6add7048029", null ],
    [ "drv_bh1745_persistance_set", "group__bh1745__color.html#gaa233270b46cd06bad7ed7a866ff49d0e", null ],
    [ "drv_bh1745_sw_reset", "group__bh1745__color.html#ga1969e372245046c174d54e6a7792a42e", null ],
    [ "drv_bh1745_threshold_get", "group__bh1745__color.html#ga429584f9d8ff069549b8569fc35e1a6e", null ],
    [ "drv_bh1745_threshold_set", "group__bh1745__color.html#gabf2ad3592958393a7bf34a9cecbf3a61", null ]
];