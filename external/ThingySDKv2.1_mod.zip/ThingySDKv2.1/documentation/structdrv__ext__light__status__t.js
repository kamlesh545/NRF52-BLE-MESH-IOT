var structdrv__ext__light__status__t =
[
    [ "active_time_ms", "structdrv__ext__light__status__t.html#a9cc5cb3a61f1ed082266362135887d07", null ],
    [ "colors", "structdrv__ext__light__status__t.html#a88722f81f025fd8ce2c083ac51c53478", null ],
    [ "inactive_time_ms", "structdrv__ext__light__status__t.html#a19f3f024ca76b5842555850c101eed73", null ],
    [ "ioext_osc_status", "structdrv__ext__light__status__t.html#a36aba2f7864c9216d375632f5aa0dc6f", null ]
];